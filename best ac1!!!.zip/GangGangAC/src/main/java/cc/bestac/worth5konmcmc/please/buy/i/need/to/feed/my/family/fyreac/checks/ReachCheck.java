package cc.bestac.worth5konmcmc.please.buy.i.need.to.feed.my.family.fyreac.checks;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class ReachCheck implements Listener {
    @EventHandler
    public void onEvent(EntityDamageByEntityEvent event){
        if (event.getDamager() instanceof Player){
            event.getDamager().sendMessage("reach detected stop it n00b");
        }
    }
}
