package cc.bestac.worth5konmcmc.please.buy.i.need.to.feed.my.family.fyreac.checks;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class AutoClickerCheck implements Listener {
    @EventHandler
    public void onSwing(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_AIR && event.getAction() != Action.LEFT_CLICK_BLOCK) {
            return;
        }

        event.getPlayer().sendMessage("Yea stop autoclick buddy!");
    }
}
