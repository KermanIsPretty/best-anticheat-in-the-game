package cc.bestac.worth5konmcmc.please.buy.i.need.to.feed.my.family.fyreac;

import cc.bestac.worth5konmcmc.please.buy.i.need.to.feed.my.family.fyreac.checks.*;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;

public final class FyreAC extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        getLogger().info("Loading FyreAC");

        Arrays.asList(new AutoClickerCheck(), new FlyCheck(), new SpeedCheck(), new KillAuaraCheck(), new ReachCheck()).forEach(check -> Bukkit.getPluginManager().registerEvents(check,this));

        getLogger().info("Finished loading FyreAC");
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
