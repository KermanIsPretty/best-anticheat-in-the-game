package cc.bestac.worth5konmcmc.please.buy.i.need.to.feed.my.family.fyreac.checks;

import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class SpeedCheck implements Listener {
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo().getBlock() != event.getFrom().getBlock() && (event.getPlayer().getLocation().getBlock().getRelative(BlockFace.DOWN) != null || event.getPlayer().getLocation().getBlock().getRelative(BlockFace.DOWN).getType() != Material.AIR)) {
            event.getPlayer().sendMessage("Stop speeding");
        }
    }
}
